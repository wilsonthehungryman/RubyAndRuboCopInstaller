RubyAndRuboCop Installer

Installs Ruby 2.3.3, DevKit 4.7.2, RuboCop, and rails into a 64bit Windows environment.

Download the zip file.
Extract the zip file.
Run setup.bat.
Install ruby to 'C:\Ruby23-x64' (should be the default).
Install the dev kit to 'C:\RubyDevKit'.

** Assumes you have Atom installed
** Ruby must be installed to 'C:\Ruby23-x64'
** DevKit must be installed to 'C:\RubyDevKit'
